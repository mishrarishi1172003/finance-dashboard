import { useState } from "react";
import { data } from "./data/data";
import RoleToggle from "./components/RoleToggle";
import Transactions from "./components/Transactions";
import Insights from "./components/Insights";

function App() {
  const [role, setRole] = useState("viewer");

  const income = data.filter(d => d.type==="income").reduce((a,b)=>a+b.amount,0);
  const expense = data.filter(d => d.type==="expense").reduce((a,b)=>a+b.amount,0);
  const balance = income - expense;

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Finance Dashboard</h1>

      <RoleToggle role={role} setRole={setRole} />

      <div>
        <p><b>Total Balance:</b> ₹{balance}</p>
        <p><b>Income:</b> ₹{income}</p>
        <p><b>Expenses:</b> ₹{expense}</p>
      </div>

      <Transactions data={data} role={role} />
      <Insights data={data} />
    </div>
  );
}

export default App;

const Insights = ({ data }) => {
  const expenses = data.filter((d) => d.type === "expense");

  let highest = expenses[0];
  expenses.forEach((e) => {
    if (e.amount > highest.amount) highest = e;
  });

  return (
    <div>
      <h2>Insights</h2>
      <p>Highest Spending: {highest.category} (₹{highest.amount})</p>
    </div>
  );
};

export default Insights;

const RoleToggle = ({ role, setRole }) => {
  return (
    <div style={{ marginBottom: "10px" }}>
      <label>Role: </label>
      <select value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="viewer">Viewer</option>
        <option value="admin">Admin</option>
      </select>
    </div>
  );
};

export default RoleToggle;

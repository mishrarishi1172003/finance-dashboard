import { useState } from "react";

const Transactions = ({ data, role }) => {
  const [filter, setFilter] = useState("all");

  const filteredData =
    filter === "all" ? data : data.filter((d) => d.type === filter);

  return (
    <div>
      <h2>Transactions</h2>

      <select onChange={(e) => setFilter(e.target.value)}>
        <option value="all">All</option>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>

      {role === "admin" && <button style={{marginLeft:"10px"}}>Add Transaction</button>}

      <table border="1" cellPadding="8" style={{marginTop:"10px"}}>
        <thead>
          <tr>
            <th>Date</th>
            <th>Amount</th>
            <th>Category</th>
            <th>Type</th>
          </tr>
        </thead>

        <tbody>
          {filteredData.map((t) => (
            <tr key={t.id}>
              <td>{t.date}</td>
              <td>₹{t.amount}</td>
              <td>{t.category}</td>
              <td>{t.type}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Transactions;

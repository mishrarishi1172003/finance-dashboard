# Finance Dashboard UI

## Description
Simple finance dashboard built for internship assignment.

## Features
- Balance, income, expense summary
- Transactions with filter
- Role-based UI
- Insights

## Run
npm install
npm run dev


Created by Rishabh Mishra
